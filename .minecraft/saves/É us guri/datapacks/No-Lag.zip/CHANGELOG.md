### Changed

- wrong version warnings also for versions above 1.19.4
- more options for entity freezing distance, now up to 130 blocks (thanks to @HanosThePlacid)

### Fixed

- Warden was affected by entity freezing, prevented it from disappearing naturally (thanks to @HanosThePlacid)
